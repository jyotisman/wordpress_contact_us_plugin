=== Custom post type Contact Form ===
Smooth  Contact form that sends the data to database save option, form styling option and admin settings.

== Description ==

Build up a nice looking quick contact form for your wordpress site in less than a minute using Custom post .This form also has option to save the contact details into database. 

The Plugin has the following Features:  

* Save contact details to database (Have a list of contact details in form data.
* Style your form with multiple styling options.
* Can be integrated using shortcode or sidebar widget.


It is an extremely easy form, that doesn�t require any additional settings, All you need is just to activate the plugin and insert the shortcode [sitepoint_contact_form] into any wordpress post/page. 
== Installation ==

The quickest method for installing this MN Contact Form plugin is:

1. Visit Plugins -> Add New Plugin in the WordPress dashboard
2. Upload full file/folder in plugin folder
3. Click on "Install Now" link.
4. Finally click "Activate Plugin".

Once the plugin is installed and activated, start integrating the plugin in your wordpress page or wordpress sidebar.

- To integrate within wordpress page use the short code : [sitepoint_contact_form]
== short code== 
[sitepoint_contact_form]