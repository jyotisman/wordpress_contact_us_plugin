jQuery(document).ready(function() {
 
    jQuery("#ContactForm16").validate();
 
});